# Architecture du laboratoire

## Flux

Navigateur -> HTTP local -> app.py -> domain.py -> SQLite -> réponse -> navigateur.
Le cookie opaque identifie une session de démonstration conservée par le serveur.
Le rôle est résolu depuis les profils du serveur, pas depuis un champ de rôle
envoyé avec une mutation. Le sélecteur de profil est une simulation explicite.

## Donnees

Table requests : id entier, title texte, owner identifiant de profil, status
parmi ouvert/ferme. Les trois lignes initiales servent tous les scénarios.
Les écritures utilisent des paramètres SQL et une transaction par action.

## Contrats

Les unités DEM-01 et DEM-02 sont définies dans BACKLOG.md et détaillées dans
README.md. La règle de longueur utilise les points de code Python, pas une
mesure visuelle des graphèmes. Les accents simples et les textes français
ordinaires sont admis ; ce choix doit être revu pour une saisie internationale
qui exige un comptage des caractères perçus.

## Execution

Serveur local synchrone, SQLite local, pas d'appel extérieur. Le démarrage refuse
un fichier existant qui ne possède pas le schéma attendu. Il ne le remplace pas.
Les tests utilisent un répertoire temporaire, un port attribué par le système
et arrêtent uniquement le serveur qu'ils ont eux-mêmes démarré.
