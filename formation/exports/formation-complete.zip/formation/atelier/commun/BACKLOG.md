# Backlog pédagogique

## DEM-01

- [~] Valider les titres de 3 à 80 caractères après trim, refuser le reste avec
  HTTP 400 sans création. Preuves : tests unitaires des bornes, intégration API,
  saisie réelle depuis la création dans l'interface.

## DEM-02

- [~] Faire appliquer la matrice de clôture par le serveur : Alice toute demande,
  Bob uniquement les siennes, Eve aucune. Preuves : matrice unitaire, appel direct
  avec session Bob vers la demande 1 refusé, parcours Alice et Bob dans l'UI.

## DEM-03

- [ ] Permettre uniquement au responsable de rouvrir une demande fermée, sans
  dupliquer ni perdre la demande. Réouverture répétée autorisée sans effet
  supplémentaire. Livrer route, commande visible, refus, tests et documentation.
  Cette unité constitue l'évaluation finale ; elle n'est pas livrée au départ.

## LAB-00

- [~] Infrastructure pédagogique : sessions simulées, seed reproductible, routes,
  affichage, tests. Le participant qualifie les preuves qu'il a effectivement
  rejouées avant de changer un statut. La présence du corrigé ne vaut pas preuve.
